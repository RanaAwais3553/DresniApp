import React, { useEffect } from 'react';
import { View, Image, Platform } from 'react-native'
import { useSelector, useDispatch } from 'react-redux'
import AuthNavigation from './Auth-Navigation';
import AppNavigation from './App-Navigation';
import { Walkthrough } from './Auth-Navigation'

import { navigationRef } from './root-navigate';
import { NavigationContainer } from '@react-navigation/native'
import { loginUser } from "../redux/actions/auth";
import { CheckWalkthrough } from "../redux/actions/setup";
import { moderateScale } from '../utilities';

const AppRoutes = () => {
    const dispatch = useDispatch();
    const authState = useSelector(state => state.auth)
    const setupState = useSelector(state => state.setup)

    useEffect(() => {
        dispatch(loginUser());
    }, [])

    useEffect(() => {
        dispatch(CheckWalkthrough());
    }, [authState.token])

    if (authState.loading || setupState.loading) {
        return (
            <View style={{ flex: 1, backgroundColor: '#F9F8FA', justifyContent: 'center', alignItems: 'center' }}>
                <Image
                    style={{ width: moderateScale(200), height: moderateScale(200), borderRadius: moderateScale(100) }}
                    source={require("../assets/Images/loader.gif")} />
            </View>
        );
    };

    return (
        <NavigationContainer ref={navigationRef}>
            {
                !setupState.wScreens ?
                    <Walkthrough /> :
                    (authState.token ? (
                        <AppNavigation />
                    ) : (
                        <AuthNavigation />
                    ))
            }
        </NavigationContainer>
    );
};

export default AppRoutes;