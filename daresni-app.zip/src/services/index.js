import AsyncStorageService from './storage-service'

export {
    AsyncStorageService
}