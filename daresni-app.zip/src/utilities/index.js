import { moderateScale, scale, verticalScale, _width, _height } from './scaling';

export {
    moderateScale,
    scale,
    verticalScale,
    _width,
    _height
};